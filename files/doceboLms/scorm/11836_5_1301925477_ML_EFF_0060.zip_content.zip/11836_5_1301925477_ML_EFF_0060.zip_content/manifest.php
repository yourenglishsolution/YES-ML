<?php 

$Type = "Quizz";
$Title = "Word power";
$Author = "WR:AW. PR:LF.";
$Description = "Wow, time has just flown by.  To wrap things up today, I have a new Word of the Day for you, and a fun little quiz.  I hope you enjoy it.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>