<?php 
$QuizzTitle = "Household items";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "0DGPC",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "12GX6",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Fill in the blank with the best word from the drop down menu. Pay attention: the questions are in the negative form.</i><br/>You cannot listen to [<span style=\"border-bottom: 1px black dashed\">a painting</span>].<br>You cannot read [<span style=\"border-bottom: 1px black dashed\">an apple</span>].<br>You cannot drink [<span style=\"border-bottom: 1px black dashed\">a pizza</span>].<br>You cannot eat [<span style=\"border-bottom: 1px black dashed\">a cocktail</span>].",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "C6Q83",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the best answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("a doctor", "a teacher", "a businessman"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "VG0ZW",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "Drag and drop your answers to match the word on the left with its image on the right.",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "a computer", 'right' => "", 'distractor' => false), array('left' => "a printer", 'right' => "", 'distractor' => false), array('left' => "a chair", 'right' => "", 'distractor' => false)),
			"Lefts" => array("a computer", "a printer", "a chair"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "12TTA",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>