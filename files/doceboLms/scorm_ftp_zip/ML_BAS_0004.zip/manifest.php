<?php 

$Type = "Quizz";
$Title = "Household items";
$Author = "WR:RB. PR: LF.";
$Description = "Welcome to today's lesson on occupations, simple adjectives, and household items.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>