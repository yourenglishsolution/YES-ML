<?php 
$QuizzTitle = "Numbers";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "RIJTR",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "RJ8JK",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the correct answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("5", "8", "15"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "O4MHG",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the correct answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("7", "12", "18"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JTXV1",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the correct answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("13", "16", "17"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "0M3PA",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Now, we will do an activity on telling the time.</i><br><br>Choose the correct words that match the times below.",
			"Type" => "MATCH",
			"Answers" => array("3:45", "3:40", "4:15", "4:30"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "BGOXC",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Select the missing word to complete the sentence.</i><br><br>For example, <i>Do you ____ in France? &#8594; LIVE</i>",

			"Type" => "TABQCU",

			"Answers" => array("\"Do you _ in France?\"", "\"Where are you _?\"", "\"Are you _ London?\"", "\"Where do you _?\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>FROM<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>LIVE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("false", "true"),
								array("true", "false"),
								array("true", "false"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "XDJL3",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>