<?php 

$Type = "Quizz";
$Title = "Numbers";
$Author = "WR: RB. PR: LF.";
$Description = "Welcome to your microlearning. Today, we are working with numbers.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>