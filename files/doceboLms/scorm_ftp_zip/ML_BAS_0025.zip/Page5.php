<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><?php 
if ($GLOBALS['ClassToInstanciate'] == 'QuestionManager')
{
	class QuestionManager
	{
		var $nbRows;	
		var $weight;

		var $Answer;
		var $ScoringMethod;

		function QuestionManager()
		{
			$this->ScoringMethod = "OneRightOnePoint";

			$this->nbRows = 3;
			$this->weight = 3;

			
			$this->Answer[] = "0";
			
			$this->Answer[] = "1";
			
			$this->Answer[] = "2";
							
		}

		function GetScore()
		{
			$score = 0;
			$bQuestionIsAnswered = false;
			$maxScore = $this->nbRows;
			
			if ($maxScore == 0)
				return 0;
				
			foreach ($this->Answer as $n => $expectedAnswer)
			{
				if ($_GET["DD".($n+1)] === '')
					continue;
				
				$bQuestionIsAnswered = true;
				
				if ($expectedAnswer == $_GET["DD".($n+1)])
					$score++;
				
			}

			if (!$bQuestionIsAnswered)
				return 0;
			
			if ($this->ScoringMethod == 'AllRight')
				$score = ($score == $maxScore) ? $this->weight : -1 * $this->weight;
			else
				$score = ($this->weight * $score) / $maxScore;

				
			// no negative score allowed :
			if ($score < 0)
				$score = 0;
				
			
			return $score;
		}
	};

	
}
else
{
	class QuestionDisplayer extends QuestionDisplayerBase
	{
		var $AnswerText;

		var $nbRows;	
		var $weight;

		var $Answer;
		var $ScoringMethod;

		function QuestionDisplayer()
		{
			$this->QuestionDisplayerBase();
			$this->QuestionType = 'dragdrop_question';

			$this->ScoringMethod = "OneRightOnePoint";

			$this->nbRows = 3;
			$this->weight = 3;

			
			$this->Answer[] = "0";
			
			$this->Answer[] = "1";
			
			$this->Answer[] = "2";
					
		}

		function PrintCorrection($bInCorrection)
		{
			if ($bInCorrection)
			{
				$AnswerText =	"<table width=\"100%\" class=\"Correction\" ><tr><td class=\"ProcessInlineImages Correction\">";

				$Score = $GLOBALS['QuizzManager']->GetCurrentPageData("Score");
				$ScoreMax = $GLOBALS['QuizzManager']->GetCurrentPageData("MaxScore");

				if ($ScoreMax > 0)
				{
					if ($Score <= 0) 
						$AnswerText .= "<p><span style=\"font-weight: bold\" epiLang=\"HintHeaderBadString\"></span></p>";
					else if ($Score < $ScoreMax)
						$AnswerText .= "<p><span style=\"font-weight: bold\" epiLang=\"HintHeaderHalfString\"></span></p>";
					else 
						$AnswerText .= "<p><span style=\"font-weight: bold\" epiLang=\"HintHeaderCorrectString\"></span></p>";
				}

				
				$AnswerText .= "<p></p>";
				
				
				if ($Score != $ScoreMax)
				{				
					$AnswerText .= "<p><span epiLang=\"CorrectionTextHead\"></span></p>";
					
					$AnswerText .=	"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">";

					
					$AnswerText .=	"<tr>";
					$AnswerText .=	"<td class=\"Correction\" ><li>golf clubs</td>";

					

					$AnswerText .=	"<td class=\"Correction\" ><li>A1_U3_golf_clubs.jpg</td>";

					

					$AnswerText .=	"</tr>";
					
					$AnswerText .=	"<tr>";
					$AnswerText .=	"<td class=\"Correction\" ><li>basketball</td>";

					

					$AnswerText .=	"<td class=\"Correction\" ><li>A1_U3_ball.jpg</td>";

					

					$AnswerText .=	"</tr>";
					
					$AnswerText .=	"<tr>";
					$AnswerText .=	"<td class=\"Correction\" ><li>baseball</td>";

					

					$AnswerText .=	"<td class=\"Correction\" ><li>A1_U3_baseball_ball.jpg</td>";

					

					$AnswerText .=	"</tr>";
					

					$AnswerText .=	"</table>";
				}

				if ($GLOBALS['QuizzManager']->InCorrection())
					$AnswerText .= '<p align="right" style="font-weight:bold"><a class="TOC_Content" href="_ManagerFrame.php?PageNumber='.$GLOBALS['QuizzManager']->GetCurrentPageIndex().'&Direction=4&NavigationDirectAccess=END"><span epiLang="GoBackToEndPage">Go back to the end page</span></a></p>';
				
				$AnswerText .=	"</td></tr></table>";

				echo $AnswerText;
			}
		}		

		function echoCorrectAnswer($bInCorrection, $DDPosition)
		{
			if (!$bInCorrection)
				return;

			$GetData = $GLOBALS['QuizzManager']->GetCurrentPageData('Answers');
			if (!isset($GetData["DD".($DDPosition+1)]))
			{
				echo '<td bgcolor="white" width="20" ><img src="_images/wrong_answer.gif" style="vertical-align: middle; margin-right: 5px"></td>';
				return;
			}
			
			$expectedAnswer = $this->Answer[$DDPosition];

			if ($expectedAnswer == $GetData["DD".($DDPosition+1)])
				echo '<td bgcolor="white" width="20" ><img src="_images/correct_answer.gif" style="vertical-align: middle; margin-right: 5px"></td>';
			else
				echo '<td bgcolor="white" width="20" ><img src="_images/wrong_answer.gif" style="vertical-align: middle; margin-right: 5px"></td>';
		}

		function getUserAnswer($bInCorrection, $RowId)
		{	
			//returns '' or a number from 0 to N corresponding to the answer to the given row
			$Answers = $GLOBALS['QuizzManager']->GetCurrentPageData('Answers');

			if (!isset($Answers["DD".$RowId]) || $Answers["DD".$RowId] === '')
				return "'-'";
			else
				return $Answers["DD".$RowId];

			return "'-'";
		}

		function DisplayPage($bInCorrection, $bLastQuestion, $HasAnsweredAllQuestions)
		{
?><html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Sports</title>
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans|Droid+Serif|Droid+Sans+Mono">
<link rel="stylesheet" type="text/css" href="_ressources/reset.css" media="all">
<link rel="stylesheet" type="text/css" href="_ressources/style.css" media="all">
<link rel="stylesheet" type="text/css" href="_ressources/stylesheets/formalize.css" media="all"><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script><script src="_ressources/javascripts/jquery.formalize.js"></script><link rel="stylesheet" href="_images/default_css.css" type="text/css"><script type="text/javascript" language="JavaScript" src="_scripts/prototype.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/language.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/Question.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/OpenPopupImage.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/Bar.js"></script><script type="text/vbscript" language="VBScript">
	
		// Catch FS Commands in IE, and pass them to the corresponding JavaScript function.
	
		Sub FlashMovie_FSCommand(ByVal command, ByVal args)
			call FlashMovie_DoFSCommand(command, args)
		end sub
		
	</script><script type="text/javascript" language="JavaScript" src="_scripts/InlineMedia.js"></script><script type="text/javascript" language="JavaScript">
		
		var AvailableMedia = new Array();
		
		AvailableMedia[0] = "A1_U3_aspirin.jpg";
		
		AvailableMedia[1] = "A1_U3_ball.jpg";
		
		AvailableMedia[2] = "A1_U3_baseball_ball.jpg";
		
		AvailableMedia[3] = "A1_U3_bat.jpg";
		
		AvailableMedia[4] = "A1_U3_cycling.jpg";
		
		AvailableMedia[5] = "A1_U3_goal.jpg";
		
		AvailableMedia[6] = "A1_U3_golf_clubs.jpg";
		
		AvailableMedia[7] = "A1_U3_racket.jpg";
		
		AvailableMedia[8] = "A1_U3_running.jpg";
		
		AvailableMedia[9] = "A1_U3_trainers.jpg";
		
		AvailableMedia[10] = "A1_W5_D5_medicine.mp3";
		
		AvailableMedia[11] = "bike.jpg";
		
		AvailableMedia[12] = "screenshot_03.jpg";
		

		var AvailableReducedImages = new Array();
		</script><?php 

	echo $GLOBALS['QuizzManager']->GetTOCScript();
	
?><meta http-equiv="imagetoolbar" content="no">
</head>
<body dir="ltr">
<form name="MyQuizzForm" action="_ManagerFrame.php" method="get"><input type="hidden" name="PageNumber" value="4"><input type="hidden" name="Direction" value="0"><input type="hidden" name="ShowAnswer" value="0"><input type="hidden" name="TimeMax" value="0"><input type="hidden" name="MaxTries" value="0"><input type="hidden" name="NavigationDirectAccess" value=""><script type="text/javascript" language="JavaScript">
  // ***** Record and Compare configuration *****

  // Lock applets
  var lockApplets = true;

  // Submit page only when all recordings have been recorded and listened
  var checkSubmit = false;

  // ********************************************
</script><div id="core">
</div>
<div id="cntrls">
<div id="cntrls_c">
<div id="cntrls_dcrs"></div>
<div id="cntrls_btns"><?php 
	echo '<span id="question_number" class="question_number" >' . $GLOBALS['QuizzManager']->GetQuestionNavigator() . '</span>';
?><a class="prev" id="prev" href="javascript:Previous()"></a><a class="submit" id="next" href="javascript:SubmitPage();"></a></div>
</div>
</div>
<div id="lssn">
<p class="txt"><b><table id="Question_text" class="Question_text" width="100%" cellspacing="0" cellpadding="4">
<tr class="Question_text">
<td class="Question_text ProcessInlineImages" valign="top"><i>Match the pictures to the words.</i></td>
</tr>
<tr class="Question_text">
<td class="Question_text" align="center" valign="top">
</td></tr>
</table></b></p>
<p class="nswr"><script type="text/javascript" src="_scripts/wz_dragdrop.js"></script><script type="text/javascript" language="JavaScript">
		var bDontScrollDraggables;
</script><style type="text/css" media="print, screen, all">
.basket {visibility: hidden}
</style>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top"><table id="Question_answers" bgcolor="black" class="Question_answers" cellpadding="1" cellspacing="1">
<tr class="AnswerRow1">
<td bgcolor="white" height="50" class="Question_answers">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">golf clubs</td>
</tr>
</table><input type="hidden" value="" name="DD1" id="DDId1"></td>
<td bgcolor="white" valign="top" width="100" height="50" class="dragOverOff" id="DropPlaceHolder1"> </td><?php  $this->echoCorrectAnswer($bInCorrection, 1 - 1); ?>
</tr>
<tr class="AnswerRow0">
<td bgcolor="white" height="50" class="Question_answers">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">basketball</td>
</tr>
</table><input type="hidden" value="" name="DD2" id="DDId2"></td>
<td bgcolor="white" valign="top" width="100" height="50" class="dragOverOff" id="DropPlaceHolder2"> </td><?php  $this->echoCorrectAnswer($bInCorrection, 2 - 1); ?>
</tr>
<tr class="AnswerRow1">
<td bgcolor="white" height="50" class="Question_answers">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">baseball</td>
</tr>
</table><input type="hidden" value="" name="DD3" id="DDId3"></td>
<td bgcolor="white" valign="top" width="100" height="50" class="dragOverOff" id="DropPlaceHolder3"> </td><?php  $this->echoCorrectAnswer($bInCorrection, 3 - 1); ?>
</tr>
</table></td>
<td valign="top"> </td>
<td valign="top"><table width="150" height="150" border="0" cellspacing="0" cellpadding="3">
<tr>
<td id="Basket" class="basket" valign="top">
<table id="bloc0" style="position:relative" width="150" height="60" class="draggableTable" border="0"><tr>
<td>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">A1_U3_golf_clubs.jpg</td>
</tr>
</table>
</td></tr></table>
<table id="bloc1" style="position:relative" width="150" height="60" class="draggableTable" border="0"><tr>
<td>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">A1_U3_ball.jpg</td>
</tr>
</table>
</td></tr></table>
<table id="bloc2" style="position:relative" width="150" height="60" class="draggableTable" border="0"><tr>
<td>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top" align="center" class="ProcessInlineImages">A1_U3_baseball_ball.jpg</td>
</tr>
</table>
</td></tr></table>
</td>
</tr>
</table></td>
</tr>
</table></p>
<p class="crrctn"><span id="Correction" class="Correction"><?php 
	$this->PrintCorrection($bInCorrection);
?></span></p>
<p class="cmmnt"><div id="Comment" class="Comment"></div>
</p>
</div><script type="text/javascript" language="JavaScript">
bDontScrollDraggables = true;
</script></form><script type="text/javascript" language="JavaScript" src="_scripts/DragDrop.js"></script><script type="text/javascript">

myQuizz = new Question_DragDrop("myQuizz", document.MyQuizzForm, "OneRightOnePoint");


myQuizz.DontAllowSubmitIfEmpty = false;


// warning : the dd.elements index is reversed to this one !
SET_DHTML(CURSOR_MOVE, "bloc2", "bloc1", "bloc0");

var DropDestinations = new Array('DropPlaceHolder1', 'DropPlaceHolder2', 'DropPlaceHolder3');
var DropInputs = new Array('DDId1', 'DDId2', 'DDId3');

var userAnswers = new Array(<?=$this->getUserAnswer($bInCorrection, 1) ?>, <?=$this->getUserAnswer($bInCorrection, 2) ?>, <?=$this->getUserAnswer($bInCorrection, 3) ?>);

// Onload : we reset the posted values
for (var i = 0; i < DropDestinations.length; i++)
{
	if (userAnswers[i] != '-')
		MoveObjectToDestination(dd.elements[dd.Int(userAnswers[i])], i);
}

var basketElement = document.getElementById('Basket');
basketElement.style.visibility = "visible";

/* THIS ONE IS CALLED ONCE AN ITEM IS DROPPED
See the description of my_PickFunc for what's accessible from here.
Here may be investigated, for example, what's the name (dd.obj.name)
of the dropped item, and where (dd.obj.x, dd.obj.y) it has been dropped... */
function my_DropFunc()
{
	var debugString = " drop pos : " + dd.obj.x + " x " +dd.obj.y;

	var bDropDestinationFound = false;

	for (var i = 0; i < DropDestinations.length; i++)
	{
		var aDropDestination = document.getElementById(DropDestinations[i]);

		if (IsPointInElement(dd.obj, aDropDestination))
		{
			MoveObjectToDestination(dd.obj, i);
			bDropDestinationFound = true;

 			break;
		}
	}

	if (!bDropDestinationFound)
	{
		var basketElement = document.getElementById('Basket');

		dd.obj.div = basketElement.appendChild(dd.obj.div);
		dd.obj.moveTo(dd.obj.defx, dd.obj.defy);
	}

	for (var i = 0; i < DropDestinations.length; i++)
	{
		var aDropDestination = document.getElementById(DropDestinations[i]);

		NoEmptyDestination(aDropDestination);
	}

	dd.recalc();
}

function IsPointInElement(obj, element)
{
	var testX = dd.e.x;
	var testY = dd.e.y;

	dd.getPageXY(element);

	var testElementLeft = dd.x;
	var testElementRight = dd.x + element.clientWidth;
	var testElementTop = dd.y;
	var testElementBottom = dd.y + element.clientHeight;

	return testX >= testElementLeft && testX <= testElementRight &&
				 testY >= testElementTop && testY <= testElementBottom;
}

function ResetDestination(Destination)
{
	var basketElement = document.getElementById('Basket');

	for (var d_i = 0; d_i < dd.elements.length; d_i++)
	{
		var d_o = dd.elements[d_i];

		if (d_o.div.parentNode.id == Destination.id)
		{
			d_o.div = basketElement.appendChild(d_o.div);
			d_o.moveTo(d_o.defx, d_o.defy);
		}
	}

	Destination.className = "dragOverOff";
	Destination.innerHTML = "";
}

function MoveObjectToDestination(obj, i)
{
	var dest = document.getElementById(DropDestinations[i]);

	ResetDestination(dest);

	obj.div = dest.appendChild(obj.div);
	obj.moveTo(obj.defx, obj.defy);

	// set the form value
	var ObjId = new String(obj.id);
	ObjId = ObjId.substr(4);

	var HiddenFormElement = document.getElementById(DropInputs[i]);
	HiddenFormElement.value = ObjId;
}

function NoEmptyDestination(Destination)
{
	for (var d_i = 0; d_i < dd.elements.length; d_i++)
	{
		var d_o = dd.elements[d_i];

		if (d_o.div.parentNode.id == Destination.id)
		{
			Destination.className = "dragOverSet";
			return;
		}
	}

	Destination.className = "dragOverOff";
	Destination.innerHTML = " ";

	// set the form value
	var ObjId = new String(Destination.id);
	ObjId = dd.Int(ObjId.substr(15));
	var HiddenFormElement = document.getElementById("DDId" + ObjId);
	HiddenFormElement.value = "";	
}

/* my_DragFunc IS CALLED WHILE AN ITEM IS DRAGGED
See the description of my_PickFunc above for what's accessible from here. */
function my_DragFunc()
{
	for (var i = 0; i < DropDestinations.length; i++)
	{
		var aDropDestination = document.getElementById(DropDestinations[i]);

		if (IsPointInElement(dd.obj, aDropDestination))
		{
			aDropDestination.className = "dragOverOn";
		}
		else
		{
			if (aDropDestination.innerHTML == " " ||
					aDropDestination.innerHTML == "&nbsp;")
				aDropDestination.className = "dragOverOff";
			else
				aDropDestination.className = "dragOverSet";
		}
	}
}

function ResetDragDropBasketTopPosition()
{
	var basket = $('Basket');

	var ElementTopOffset = Position.cumulativeOffset(basket)[1];

	var Target = $('Question_answers');
	var dim = Target.getDimensions();
	var TargetBottom = Position.cumulativeOffset(Target)[1] + dim.height;

	if (TargetBottom < document.body.scrollTop)
		basket.style.paddingTop = 3 + TargetBottom - ElementTopOffset;
	else if (document.body.scrollTop > ElementTopOffset)
		basket.style.paddingTop = 3 + document.body.scrollTop - ElementTopOffset;
	else
		basket.style.paddingTop = 3;
}

if (!bDontScrollDraggables)
	window.onscroll = ResetDragDropBasketTopPosition;

</script><script type="text/javascript" language="JavaScript">

	var StartTime = new Date();	
	var myTimer = null;
	var bCountDown = null;
	var nbsTries;
	
	<?php 
	
	$DisableQuizzNow = false;

	

	if ($GLOBALS['QuizzManager']->GetCurrentPageData("HintCycle") == 1)
		$DisableQuizzNow = true;

	if ($GLOBALS['QuizzManager']->GetCurrentPageData("Disabled"))
		$DisableQuizzNow = true;

	if ($bInCorrection)
	{
		$DisableQuizzNow = true;
		echo "var IsInCorrection = true;\n";
	}
	else
		echo "var IsInCorrection = false;\n";
	
	if ($DisableQuizzNow)
		echo "myQuizz.DisableForm();\n";
	else
		echo "PrepareCounter();\n";
		
?>
	
	function SubmitPage()
	{
		if (myQuizz.enable && !myQuizz.canSubmit())
			return;
	
		<?php 
			$noTries = false;
			
			$noTries = true;
			
		
		if ($bLastQuestion &&
				!$bInCorrection &&
				($DisableQuizzNow || $noTries))
		{
			if (!$HasAnsweredAllQuestions)
			{
		?>
			if (!confirm(EpiLangJS.YouHaveReachTheLastPageButHanventAnsweredAllQuestions))
				return;
		<?php 
			}
			else
			{
		?>

			if (!confirm(EpiLangJS.YouHaveReachTheLastPage))
				return;

		<?php 
			}
		}
		?>
		
		document.MyQuizzForm.Direction.value = 0;
		myQuizz.submit();
	}
	
	function Next()
	{
		if (myQuizz.enable && !myQuizz.canSubmit())
			return;

		<?php 
		
		if ($bLastQuestion && !$bInCorrection)
		{
			if (!$HasAnsweredAllQuestions)
			{
		?>
			if (!confirm(EpiLangJS.YouHaveReachTheLastPageButHanventAnsweredAllQuestions))
				return;
		<?php 
			}
			else
			{
		?>

			if (!confirm(EpiLangJS.YouHaveReachTheLastPage))
				return;

		<?php 
			}	
		}
		?>
		
		document.MyQuizzForm.Direction.value = 1;
		myQuizz.submit();
	}
	
	function Previous()
	{
		document.MyQuizzForm.Direction.value = -1;
		myQuizz.submit();
	}	

	function navigate_to_page(theSelect)
	{
		var SelectValue = theSelect.options[theSelect.selectedIndex].value;
	
		if (SelectValue == 'END')
		{
			if (!FinishNow() && theSelect.originalIndex > 0)
			{
				// revert to the current page selection
				theSelect.selectedIndex = theSelect.originalIndex - 1;
			}
		}
		else
		{
			document.MyQuizzForm.Direction.value = 2;
			myQuizz.submit();
		}
	}

	function DirectAccessTo(randomPageId)
	{
		if (randomPageId == -1)
			if (!FinishNow())
				return;

		document.MyQuizzForm.Direction.value = 4;
		document.MyQuizzForm.NavigationDirectAccess.value = randomPageId;
		
		myQuizz.submit();
	}
	
	function FinishNow()
	{
		<?php 
		
		if (!$bInCorrection)
		{
			if (!$HasAnsweredAllQuestions)
			{
		?>
			if (!confirm(EpiLangJS.YouHanventAnsweredAllQuestions))
				return false;
		<?php 
			}
			else
			{
		?>

			if (!confirm(EpiLangJS.DoYouWantToEndTheQuestionnaireNow))
				return false;

		<?php 
			}	
		}
		?>
		
		document.MyQuizzForm.Direction.value = 3;
		myQuizz.submit();
		return true;
	}
	
	function ShowAnswers()
	{
		document.MyQuizzForm.Direction.value = 0;
		document.MyQuizzForm.ShowAnswer.value = 1;
		myQuizz.submit();
	}	
	
	function PrepareCounter()
	{
<?php 
		if (!$GLOBALS['QuizzManager']->NoTimer)
		{
			$remainingTime = 0;
			$TimerMax = 0;
			$bShowCounter = false;

			if ($GLOBALS['QuizzManager']->IsGlobalTimer)
			{
				$remainingTime = $GLOBALS['QuizzManager']->GlobalTimeMax - $GLOBALS['QuizzManager']->GetSpentTime();

				$TimerMax = $GLOBALS['QuizzManager']->GlobalTimeMax;
				$bShowCounter = true;
			}
	

			if ($bShowCounter)
			{
				$GlobCounter = ($GLOBALS['QuizzManager']->IsGlobalTimer) ? "true" : "false";

				echo 'bCountDown = new Bar("bCountDown", 60, 6, '.$TimerMax.', \'_images/pt_PRBAR_on.gif\', \'_images/pt_PRBAR_off.gif\', \'_images/pt_PRBAR_half_on.gif\', \'_images/pt_PRBAR_half_off.gif\', '.$GlobCounter.', EpiLang.TimerFinished);';
				echo 'if (document.getElementById)';
				echo '	bCountDown.Build(document.getElementById("TimerBar"), '.$remainingTime.', EpiLang.GlobalTimeString, EpiLang.QuestionTimeString);';

				echo 'myTimer = new CountDown("myTimer");';
				echo 'myTimer.OnTick = _OnTick;';
				echo 'myTimer.OnTimer = _OnTimer;';
				echo 'myTimer.Start('.$remainingTime.', '.$TimerMax.', 30);';
			}
		}
?>
	}
	
	
	// -------- Timer management --------------
	function _OnTick()
	{
		bCountDown.SetPosition(myTimer.timeLeft);
	}
	
	function _OnTimer()
	{
		// this is called when the timer arrives to its end.
		
		bCountDown.SetPosition(0);
		
		myQuizz.DisableForm();
		

<?php 
		if (!$bInCorrection && !$GLOBALS['QuizzManager']->NoTimer)
		{
			if ($GLOBALS['QuizzManager']->IsGlobalTimer)
			{
				echo '		alert(EpiLangJS.TheQuizzIsFinished);';
			}
		}
?>		
		
	}

	function ShowHint()
	{
		myQuizz.ShowHint(false, "", "");
	}
	
	// -------- utilities --------------
	function SetElementVisible(elementID, bVisible)
	{
		// Show/Hide functions for pointer objects
		if (document.getElementById && document.getElementById(elementID))
		{
			if (bVisible)
			{
				document.getElementById(elementID).style.visibility = "visible";
			}
			else
			{
			  document.getElementById(elementID).style.visibility = "hidden";
			}
		}	
	}
	
	function layerWrite(id,text) 
	{
		if (document.getElementById && document.getElementById(id))
			document.getElementById(id).innerHTML = text;
	}

<?php 
	// Add the HeartBeat
	if (!empty($GLOBALS['QuizzManager']->UseHeartBeat))
	{
		if (empty($GLOBALS['QuizzManager']->HeartBeatPulsationPeriod))
			$GLOBALS['QuizzManager']->HeartBeatPulsationPeriod = 5; // Seconds

		$TimerMax = 0;

		if ($GLOBALS['QuizzManager']->IsGlobalTimer)
			$TimerMax = $GLOBALS['QuizzManager']->GlobalTimeMax;
	

		echo '	window.setTimeout(\'Pulse()\', '.$GLOBALS['QuizzManager']->HeartBeatPulsationPeriod * 1000 .');' . "\n";
		echo '	function Pulse()' . "\n";
		echo '	{' . "\n";
		echo '		var myAjax = new Ajax.Request(\'_ManagerFrame.php\',' . "\n";
		echo '													{ parameters: { HeartBeat: \'true\'' . "\n";
		echo '																				},' . "\n";
		echo '														onSuccess: OnPulseSuccess' . "\n";
		echo '													});' . "\n";
		echo '	}' . "\n";

		echo '	function OnPulseSuccess(originalRequest, json)' . "\n";
		echo '	{' . "\n";
		echo '		if (json && json.Return == "Acknowledged")' . "\n";
		echo '		{' . "\n";
		echo '			window.setTimeout(\'Pulse()\', '.$GLOBALS['QuizzManager']->HeartBeatPulsationPeriod * 1000 .');' . "\n";
		echo '			myTimer.timeLeft = '.$TimerMax.' - json.ElapsedTime; ' . "\n";
		echo '		}' . "\n";
		echo '	}' . "\n";
	}

?></script><script type="text/javascript" language="JavaScript">
	EpiLangManager.TranslatePage(document) ;
</script></body>
</html><?php 
		} // DisplayPage
	}; // class
} // else
?>
