<?php 
$QuizzTitle = "Sports";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "5JBGN",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "24FKG",
			"QuestionTitle" => "Vocabulary",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "8YQ33",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Select the word that matches the picture.</i><br><br>A1_U3_bat.jpg",

			"Type" => "QCU",

			"Answers" => array("a goal", "a bat", "a ball"),
			"Correct_Answers" => array("false", "true", "false"),
			"Comments" => array("", "", ""),
			"Profiles" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "30FFB",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the picture to its noun.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "bike", 'right' => "A1_U3_cycling.jpg", 'distractor' => false), array('left' => "trainers", 'right' => "A1_U3_trainers.jpg", 'distractor' => false), array('left' => "goal", 'right' => "A1_U3_goal.jpg", 'distractor' => false)),
			"Lefts" => array("bike", "trainers", "goal"),
			"Rights" => array("A1_U3_cycling.jpg", "A1_U3_trainers.jpg", "A1_U3_goal.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "KX8YW",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the pictures to the words.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "golf clubs", 'right' => "A1_U3_golf_clubs.jpg", 'distractor' => false), array('left' => "basketball", 'right' => "A1_U3_ball.jpg", 'distractor' => false), array('left' => "baseball", 'right' => "A1_U3_baseball_ball.jpg", 'distractor' => false)),
			"Lefts" => array("golf clubs", "basketball", "baseball"),
			"Rights" => array("A1_U3_golf_clubs.jpg", "A1_U3_ball.jpg", "A1_U3_baseball_ball.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "MHMUU",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>