<?php 
$QuizzTitle = "Family";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "7JMS8",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "U00N4",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Select the correct answer from the choices below to finish the sentence.</i><br><br>A man and a woman have the same parents, therefore, he is her...",

			"Type" => "QCU",

			"Answers" => array("father.", "brother.", "cousin.", "husband."),
			"Correct_Answers" => array("false", "true", "false", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "NAZWV",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording and select the two correct animals.</i><br><br>[[snd:A1_U2_M1_Q071b.mp3]]<br><br>What kind of pets does his son have?",

			"Type" => "QCM",

			"Answers" => array("", "", "", ""),
			"Correct_Answers" => array("false", "true", "true", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "OMFAR",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording and select the two correct answers.</i><br><br>[[snd:A1_U2_M1_Q072a.mp3]]<br><br>What are two responses you could use to answer the question on the recording?",

			"Type" => "QCM",

			"Answers" => array("&quot;No. I am an only child.&quot;", "&quot;Yes, I have.&quot;", "&quot;Yes, I do.&quot;", "&quot;No, I don't have.&quot;"),
			"Correct_Answers" => array("true", "false", "true", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "7C02G",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Listen to the recording, and select whether the information is true or false.</i><br><br>[[snd:A1_U2_M1_Q073b.mp3]]",

			"Type" => "TABQCU",

			"Answers" => array("The man has a daughter.", "His daughter has a fianc&eacute;.", "The man's daughter has three children.", "The daughter's husband is Italian."),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>TRUE<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>FALSE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("false", "true"),
								array("true", "false")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>