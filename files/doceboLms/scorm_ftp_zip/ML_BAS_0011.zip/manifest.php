<?php 

$Type = "Quizz";
$Title = "Family";
$Author = "WR: CY. PR: LF";
$Description = "Today, we're going to practice talking about our family. But first, it's time for your Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>