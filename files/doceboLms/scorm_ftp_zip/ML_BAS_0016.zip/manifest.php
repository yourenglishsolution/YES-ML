<?php 

$Type = "Quizz";
$Title = "Days, Months & Seasons";
$Author = "WR: DC/CY PR: YES";
$Description = "Hello! Today: days, months and seasons.<br><br><br><b>Word of the Day</b><br><br><br><b>printer</b><br>(noun)<br><br> [[img:A1_U2_printer.jpg]]<br><br> [[snd:A1_W4_D1_printer.mp3]]";
$Version = "2.7.2.0";
$Locale = "en.js";

?>