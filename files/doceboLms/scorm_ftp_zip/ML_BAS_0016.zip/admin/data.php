<?php 
$QuizzTitle = "Days, Months & Seasons";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "RWOYZ",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "UYNBH",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>What is the right answer?</i><br><br><b>EXAMPLE:</b><br><br>tuesday_B.jpg<br><br><b>Monday, ____, Wednesday &#8594; Monday, <font color=\"#FF0000\">Tuesday</font>, Wednesday</b><br/><b>1.</b><br>saturday_B.jpg<br><br><b>Thursday, Friday, </b>[<span style=\"border-bottom: 1px black dashed\">Saturday</span>, <span style=\"border-bottom: 1px black dashed\">Saturday.</span>]<br><br><b>2.</b><br>sunday_B.jpg<br><br>[<span style=\"border-bottom: 1px black dashed\">Sunday</span>, <span style=\"border-bottom: 1px black dashed\">Sunday,</span>]<b>, Monday, Tuesday</b>",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "K4NQZ",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>What is the right answer?</i><br><br><b>EXAMPLE:</b><br><br><b>tuesday_B.jpg = Tuesday</b><br/><b>1.</b><br>monday_B.jpg = [<span style=\"border-bottom: 1px black dashed\">Monday</span>, <span style=\"border-bottom: 1px black dashed\">Monday.</span>]<br><br><b>2.</b><br>wednesday_B.jpg = [<span style=\"border-bottom: 1px black dashed\">Wednesday</span>, <span style=\"border-bottom: 1px black dashed\">Wednesday.</span>]<br><br><b>3.</b><br>thursday_B.jpg = [<span style=\"border-bottom: 1px black dashed\">Thursday</span>, <span style=\"border-bottom: 1px black dashed\">Thursday.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "4WBOC",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>When does each month happen?</i><br><br><b>EXAMPLE:</b><br><br><b>December &#8594; Winter</b>",
			"Type" => "MATCH",
			"Answers" => array("April", "January", "August", "October"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "TQFT8",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Put the months in the correct order from 1 to 4.</i><br><br><b>EXAMPLE:</b><br><br><b>November, September, October, December</b> <b>&#8594; </b><br><i>September, October, November, December</i>",
			"Type" => "SORT",
			"Answers" => array("March", "February", "May", "April"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "DJO6V",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "[[snd:A1_U2_M3_Q013c.mp3]]<br><br><i>What season is it?</i>",

			"Type" => "QCU",

			"Answers" => array("Spring", "Summer", "Fall", "Winter"),
			"Correct_Answers" => array("false", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "CTMQC",
			"QuestionTitle" => "The End",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>