<?php 
$QuizzTitle = "Review";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "XPPCQ",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "WB3PU",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Select from the objects in the diagrams to answer the question. If you want to print an article, what two things do you use?</i>",

			"Type" => "QCM",

			"Answers" => array("", "", "", ""),
			"Correct_Answers" => array("true", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "L2J6P",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Write the name of the colours in the boxes provided.</i><br/><b>red.jpg &#8594; </b>[<span style=\"border-bottom: 1px black dashed\">red</span>, <span style=\"border-bottom: 1px black dashed\">red.</span>]<br><br><b>yellow.jpg &#8594; </b>[<span style=\"border-bottom: 1px black dashed\">yellow</span>, <span style=\"border-bottom: 1px black dashed\">yellow.</span>]<br><br><b>black.jpg &#8594; </b>[<span style=\"border-bottom: 1px black dashed\">black</span>, <span style=\"border-bottom: 1px black dashed\">black.</span>]<br><br><b>green.jpg &#8594; </b>[<span style=\"border-bottom: 1px black dashed\">green</span>, <span style=\"border-bottom: 1px black dashed\">green.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JMLJK",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the best answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("Susan worked all day. ____ is tired.", "The clothes are in the basket. ____ are dry.", "I have a new desk. ____ is in my office."),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "2AD1L",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "5",
	
			"Question" => "<i>Fill in each blank with one word to complete the sentence.</i><br/>&quot;Is this desk heavy?&quot;<br>&quot;Yes, it [<span style=\"border-bottom: 1px black dashed\">is</span>, <span style=\"border-bottom: 1px black dashed\">is.</span>].&quot;<br><br>&quot;Is this shirt dry?&quot;<br>&quot;No, it [<span style=\"border-bottom: 1px black dashed\">is not</span>, <span style=\"border-bottom: 1px black dashed\">is not.</span>, <span style=\"border-bottom: 1px black dashed\">isn't</span>, <span style=\"border-bottom: 1px black dashed\">isn't.</span>].&quot;<br><br>&quot;Are you cold?&quot;<br>&quot;[<span style=\"border-bottom: 1px black dashed\">Yes</span>], I am.&quot;<br><br>&quot;Is it cold today?&quot;<br>&quot;[<span style=\"border-bottom: 1px black dashed\">No</span>], [<span style=\"border-bottom: 1px black dashed\">it</span>] isn't.&quot;",
			"Type" => "TAT",
			"Answers" => array("", "", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "M2QS8",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Select one of more of the correct answers from below. Which of the following are greetings?</i>",

			"Type" => "QCM",

			"Answers" => array("&quot;Hi.&quot;", "&quot;Good night.&quot;", "&quot;Good morning.&quot;", "&quot;Hello there.&quot;"),
			"Correct_Answers" => array("true", "false", "true", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "OUV08",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>