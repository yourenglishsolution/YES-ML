<?php 

$Type = "Quizz";
$Title = "Review";
$Author = "WR: CY. PR: LF.";
$Description = "Today, you will have a quiz on previous lessons. First, here's our Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>