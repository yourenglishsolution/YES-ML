<?php 
$QuizzTitle = "Answering questions";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "DMWMW",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "OWZMF",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "[[snd:A1_U1_M1_RP1a.mp3]]<br><br><i>Listen to the sound recording, and choose a response that answers Sam's question.</i>",

			"Type" => "QCU",

			"Answers" => array("&quot;I call myself Pat.&quot;", "&quot;Hello. Very well, thank you.&quot;", "&quot;Pat. Pleased to meet you.&quot;", "&quot;Sorry, I don't know.&quot;"),
			"Correct_Answers" => array("false", "false", "true", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "Z3IUQ",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "[[snd:A1_U1_M1_RP3b.mp3]]<br><br><i>Listen to the sound recording, and fill in the gaps in the sentence below to answer their question.</i><br/>&quot;[<span style=\"border-bottom: 1px black dashed\">No</span>], [<span style=\"border-bottom: 1px black dashed\">I'm not</span>]. I'm French.&quot;",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "ARV41",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Look at the picture, and then select the correct answer from below.</i><br><br>Is it sunny today?",

			"Type" => "QCU",

			"Answers" => array("No, it is.", "Yes, it is.", "No, it isn't."),
			"Correct_Answers" => array("false", "true", "false"),
			"Comments" => array("", "", ""),
			"Profiles" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "KZCMG",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the best answer.</i>",
			"Type" => "MATCH",
			"Answers" => array("&quot;Is Jane British?&quot;", "&quot;Are you French?&quot;", "&quot;Is that Jane?&quot;"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>