<?php 

$Type = "Quizz";
$Title = "Answering questions";
$Author = "WR: CY. PR: LF.";
$Description = "Hello! Today, we're going to practice answering simple questions. First, here's our Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>