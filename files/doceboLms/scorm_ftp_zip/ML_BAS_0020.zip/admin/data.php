<?php 
$QuizzTitle = "Questions";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "NTBXI",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "EM645",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Finish the sentence by using 'is' or 'are'.</i><br>For example:<b> </b><i>\"Why ____ he so late?\" &#8594; \"Why is he so late?\"</i>",

			"Type" => "TABQCU",

			"Answers" => array("\"____ he here?\"", "\"Where ____ they from?\"", "\"What ____ we going to do?\"", "\"What ____ your name?\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>IS<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>ARE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("false", "true"),
								array("true", "false")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "CUSKH",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Finish the sentence by choosing 'do' or 'does'.</i><br>For example:<b> </b><i>\"</i><b>____</b><i> Jerome work all day?\" &#8594; \"Does Jerome work all day?\"</i><br/>\"[<span style=\"border-bottom: 1px black dashed\">Do</span>] you like hamburgers?\"<br><br>\"[<span style=\"border-bottom: 1px black dashed\">Does</span>] Rishi have glasses?\"<br><br>\"[<span style=\"border-bottom: 1px black dashed\">Do</span>] Amy and Antonio work on Mondays?\"",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "WE4N2",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Complete the questions.</i><br>For example:<b> </b><i>\"_</i><b>___</b><i> is your wife?\" &#8594; \"Who is your wife?\"</i><br/>\"[<span style=\"border-bottom: 1px black dashed\">How</span>] do you do that? I want to learn!\"<br><br>\"[<span style=\"border-bottom: 1px black dashed\">Where</span>] is James? I can't find him.\"",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "MHMUU",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>