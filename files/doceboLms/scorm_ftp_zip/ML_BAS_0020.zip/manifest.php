<?php 

$Type = "Quizz";
$Title = "Questions";
$Author = "WR: DC. PR:LF.";
$Description = "Welcome to your lesson. We hope you like it.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>