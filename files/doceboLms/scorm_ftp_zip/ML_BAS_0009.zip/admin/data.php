<?php 
$QuizzTitle = "Adjectives";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "8VU6P",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "UZTPA",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the images on the right with the correct adjectives on the left.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "empty", 'right' => "", 'distractor' => false), array('left' => "full", 'right' => "", 'distractor' => false), array('left' => "heavy", 'right' => "", 'distractor' => false)),
			"Lefts" => array("empty", "full", "heavy"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "63J1L",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Choose the best adjective from the drop-down list to complete each sentence.</i><br/>&quot;My computer is too [<span style=\"border-bottom: 1px black dashed\">slow</span>]. I need to get a faster one.&quot;<br><br>&quot;I am [<span style=\"border-bottom: 1px black dashed\">happy</span>] to see you!&quot;<br><br>&quot;Turn the heat up, please. It's [<span style=\"border-bottom: 1px black dashed\">freezing</span>] in here!&quot;<br><br>&quot;Take an umbrella, so you don't get [<span style=\"border-bottom: 1px black dashed\">wet</span>].&quot;",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "AP1JL",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Match the words on the left with the sentences that best describe them on the right.</i><br><br>For example: <i>It's snowing outside. It is <u>COLD</u>.</i>",
			"Type" => "MATCH",
			"Answers" => array("fast", "sad", "warm", "dry"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "UBONF",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>