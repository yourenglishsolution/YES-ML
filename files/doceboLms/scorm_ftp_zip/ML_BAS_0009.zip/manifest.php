<?php 

$Type = "Quizz";
$Title = "Adjectives";
$Author = "WR: DC. PR: LF.";
$Description = "Today, we're going to practice a few adjectives. But, first here's your Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>