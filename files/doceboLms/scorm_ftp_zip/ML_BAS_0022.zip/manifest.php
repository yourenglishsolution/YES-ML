<?php 

$Type = "Quizz";
$Title = "Your health 2";
$Author = "WR: PR: LF";
$Description = "Hello there. Let's get started.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>