<?php 
$QuizzTitle = "Your health 2";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "KSHIT",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "BQYGP",
			"QuestionTitle" => "Vocabulary",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "YRT0S",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the text to the pictures.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "A1_U3_cramp.jpg", 'right' => "a cramp", 'distractor' => false), array('left' => "A1_U3_cut.jpg", 'right' => "a cut", 'distractor' => false), array('left' => "A1_U3_headache.jpg", 'right' => "a headache", 'distractor' => false)),
			"Lefts" => array("A1_U3_cramp.jpg", "A1_U3_cut.jpg", "A1_U3_headache.jpg"),
			"Rights" => array("a cramp", "a cut", "a headache"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "P822W",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Fill in the blank.</i><br><br>A1_U3_earache.jpg<br/>An ear[<span style=\"border-bottom: 1px black dashed\">ache</span>]<b>. </b>",
			"Type" => "TAT",
			"Answers" => array(""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "CDONA",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Select the </i><b>broken leg.</b>",

			"Type" => "QCU",

			"Answers" => array("A1_U3_cramp.jpg", "A1P_U4_bdp_legs.jpg", "A1_U3_broken_leg.jpg"),
			"Correct_Answers" => array("false", "false", "true"),
			"Comments" => array("", "", ""),
			"Profiles" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "YAK08",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording, and choose the <b>two </b>correct answers.</i><br><br>[[snd:A1_U3_M1_Q009a.mp3]]<br><br>What does the woman have?",

			"Type" => "QCM",

			"Answers" => array("A1_U3_cut.jpg", "A1_U3_headache.jpg", "A1_U3_cramp.jpg", "A1_U3_acold.jpg"),
			"Correct_Answers" => array("false", "true", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "RH68C",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>