<?php 

$Type = "Quizz";
$Title = "Your health";
$Author = "WR: PR:LF.";
$Description = "Welcome back. Let's start the lesson.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>