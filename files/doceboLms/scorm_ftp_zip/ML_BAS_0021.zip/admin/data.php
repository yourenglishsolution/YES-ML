<?php 
$QuizzTitle = "Your health";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "DFY21",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "33M8X",
			"QuestionTitle" => "Vocabulary",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "CN5OC",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>What is this word?</i><br><br>A1_U3_fever.jpg",

			"Type" => "QCU",

			"Answers" => array("a cough", "a sneeze", "a fever"),
			"Correct_Answers" => array("false", "false", "true"),
			"Comments" => array("", "", ""),
			"Profiles" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "K4NQZ",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Complete the sentence below.</i><br><br>A1_U3_runny_nose.jpg<br/>He has a [<span style=\"border-bottom: 1px black dashed\">runny</span>] nose.",
			"Type" => "TAT",
			"Answers" => array(""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "NEQWP",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the pictures to the words.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "to cough", 'right' => "A1_U3_cough.jpg", 'distractor' => false), array('left' => "to sneeze", 'right' => "A1_U3_acold.jpg", 'distractor' => false), array('left' => "a fever", 'right' => "A1_U3_fever.jpg", 'distractor' => false)),
			"Lefts" => array("to cough", "to sneeze", "a fever"),
			"Rights" => array("A1_U3_cough.jpg", "A1_U3_acold.jpg", "A1_U3_fever.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "DJO6V",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording, and select one more correct answers.</i><br><br>[[snd:A1_U3_M1_Q073b.mp3]]<br><br>What does the woman have?",

			"Type" => "QCM",

			"Answers" => array("A1_U3_runny_nose.jpg", "A1_U3_fever.jpg", "A1_U3_stomachache.jpg", "A1_U3_sore_throat.jpg"),
			"Correct_Answers" => array("true", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "CTMQC",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>