<?php 
$QuizzTitle = "Thanks";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "LS0UY",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "6SC7L",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Select one of the answers from below.</i><br><br>Which of these is NOT a way to show appreciation?",

			"Type" => "QCU",

			"Answers" => array("[[snd:A1_W3_D4_a.mp3]]", "[[snd:A1_W3_D4_d.mp3]]", "[[snd:A1_W3_D4_c.mp3]]", "[[snd:A1_W3_D4_b.mp3]]", "[[snd:A1_W3_D4_e.mp3]]"),
			"Correct_Answers" => array("false", "true", "false", "false", "false"),
			"Comments" => array("", "", "", "", ""),
			"Profiles" => array("", "", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "G5SIO",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "6",
	
			"Question" => "<i>Put this conversation in the correct order.</i>",
			"Type" => "SORT",
			"Answers" => array("&quot;Yes?&quot;", "&quot;Do you have the time?&quot;", "&quot;Hi. Excuse me.&quot;", "&quot;You're welcome.&quot;", "&quot;Yes. It's a quarter past five.&quot;", "&quot;Thanks so much.&quot;"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "S4V54",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>What are the different ways you can respond to thanks? Select more than one answer.</i>",

			"Type" => "QCM",

			"Answers" => array("&quot;You're very welcome.&quot;", "&quot;That's good.&quot;", "&quot;My pleasure.&quot;", "&quot;No problem!&quot;"),
			"Correct_Answers" => array("true", "false", "true", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JC7MO",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Fill in the gap to finish the sentence correctly.</i><br><br>Somebody asks you, &quot;Do you have any gum?&quot;<br/>You say, &quot;Yes. Here [<span style=\"border-bottom: 1px black dashed\">you</span>] are<b>.</b>&quot;",
			"Type" => "TAT",
			"Answers" => array(""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>