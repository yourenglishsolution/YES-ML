<?php 

$Type = "Quizz";
$Title = "Thanks";
$Author = "WR: CY. PR: LF.";
$Description = "Today, we're going to practice giving, and responding to thanks. First, here's our Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>