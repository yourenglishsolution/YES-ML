<?php 

$Type = "Quizz";
$Title = "Greetings";
$Author = "WR: DC. PR: LF.";
$Description = "Hello! Today, we're going to practice greetings. But first, here's our Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>