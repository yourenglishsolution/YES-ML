<?php 
$QuizzTitle = "Greetings";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "ZOWNC",
			"QuestionTitle" => "Words of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "47XZY",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "5",
	
			"Question" => "<i>Select whether the expressions are greetings or farewells. </i><br><br>For example: <i>Hi! &#8594; GREETING</i>",

			"Type" => "TABQCU",

			"Answers" => array("\"Hello.\"", "\"Goodbye.\"", "\"Good morning.\"", "\"See you later.\"", "\"Bye.\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>GREETING<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>FAREWELL<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("true", "false"),
								array("false", "true"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "DTDX1",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Fill in the gap with the most appropriate choice from the menu.</i><br/>\"Hi Jim. How [<span style=\"border-bottom: 1px black dashed\">are</span>] you?\"<br>\"Just [<span style=\"border-bottom: 1px black dashed\">fine, thanks</span>]. And you?\"<br><br>\"I have to go. I'll [<span style=\"border-bottom: 1px black dashed\">see you</span>] later.\"<br>\"Okay, [<span style=\"border-bottom: 1px black dashed\">goodbye</span>].\"",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "F5OE6",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "6",
	
			"Question" => "<i>Select the times when you can say these greetings. You can select more than one answer. </i><br><br>For example:<i> Hello &#8594; BEFORE 12 P.M., BETWEEN 12 P.M. AND 5 P.M., AND AFTER 5 P.M.</i>",

			"Type" => "TABQCM",

			"Answers" => array("\"Good afternoon.\"", "\"Good morning.\"", "\"Hi there.\"", "\"Good evening.\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>BEFORE 12 P.M.<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>BETWEEN 12 P.M. AND 5 P.M.<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>AFTER 5 P.M.<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("false", "true", "false"),
								array("true", "false", "false"),
								array("true", "true", "true"),
								array("false", "false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "X68TN",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Put these sentences in the right order by selecting 1,2,3, and 4.</i>",
			"Type" => "SORT",
			"Answers" => array("\"Pleased to meet you, Nancy. I'm Jim. How do you do?\"", "\"Hi. I'm Nancy.\"", "\"Fine, thanks. And you?\"", "\"Just great! Thanks for asking.\""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>