<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><?php 
	$GLOBALS['authorEmail'] = "";

 

	class QuestionDisplayer extends QuestionDisplayerBase
	{
		function QuestionDisplayer()
		{
			$this->QuestionDisplayerBase();
			$this->QuestionType = 'result_page';
		}

		function DisplayPage()
		{
?><html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><span epiLang="ResultsString"></span></title>
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans|Droid+Serif|Droid+Sans+Mono">
<link rel="stylesheet" type="text/css" href="_ressources/reset.css" media="all">
<link rel="stylesheet" type="text/css" href="_ressources/style.css" media="all"><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script><script src="_ressources/javascripts/jquery.formalize.js"></script><link rel="stylesheet" href="_images/default_css.css" type="text/css"><script type="text/javascript" language="JavaScript" src="_scripts/prototype.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/language.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/OpenPopupImage.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/InlineMedia.js"></script><script type="text/javascript" language="JavaScript">
		
		var AvailableMedia = new Array();
		
		AvailableMedia[0] = "A1P_U1_phone.jpg";
		
		AvailableMedia[1] = "A1P_U5_presentation.jpg";
		
		AvailableMedia[2] = "A1P_U6_cinema.jpg";
		
		AvailableMedia[3] = "A1P_U6_envelope.jpg";
		
		AvailableMedia[4] = "A1_U1_sun.jpg";
		
		AvailableMedia[5] = "A1_U3_come.jpg";
		
		AvailableMedia[6] = "A1_U3_drink.jpg";
		
		AvailableMedia[7] = "A1_U3_eat.jpg";
		
		AvailableMedia[8] = "A1_U3_fever.jpg";
		
		AvailableMedia[9] = "A1_U3_go.jpg";
		
		AvailableMedia[10] = "A1_U3_play.jpg";
		
		AvailableMedia[11] = "A1_U3_see.jpg";
		
		AvailableMedia[12] = "A1_U3_throw.jpg";
		
		AvailableMedia[13] = "A1_U3_tocatch.jpg";
		
		AvailableMedia[14] = "A1_U3_tohit.jpg";
		
		AvailableMedia[15] = "A1_U3_to_kick.jpg";
		
		AvailableMedia[16] = "A1_U3_to_score.jpg";
		
		AvailableMedia[17] = "A1_U3_to_score_B.jpg";
		
		AvailableMedia[18] = "A1_U3_watch.jpg";
		
		AvailableMedia[19] = "A1_W5_D3_fever.mp3";
		
		AvailableMedia[20] = "screenshot_04.jpg";
		
		AvailableMedia[21] = "Thumbs.db";
		
		AvailableMedia[22] = "verbs.jpg";
		

		var AvailableReducedImages = new Array();
		</script><meta http-equiv="imagetoolbar" content="no">
</head>
<body dir="ltr"><script type="text/javascript" language="JavaScript">
  // ***** Record and Compare configuration *****

  // Lock applets
  var lockApplets = true;

  // Submit page only when all recordings have been recorded and listened
  var checkSubmit = false;

  // ********************************************
</script><div id="core">
</div>
<div id="cntrls">
<div id="cntrls_c">
<div id="cntrls_dcrs"></div>
<div id="cntrls_btns"><a id="see_corrections_button" class="see_corrections_button" href="javascript:document.navigationform.submit();"><img src="_images/img_answers.png" align="middle" border="0"></a></div>
</div>
</div>
<div id="rslt">
<p><?php 
	$this->EchoResultDataAndSendAICC(true, 100, false, false, true, false);	
?><br></p>
<div id="recordandcompare_results"></div>
</div><script type="text/javascript" language="JavaScript">
bDontScrollDraggables = true;
</script><script type="text/javascript" language="JavaScript">
	EpiLangManager.TranslatePage(document) ;
</script></body>
</html><?php 
		} // DisplayPage
	}; // class
	
	$PageDisplay = new QuestionDisplayer();
	
?>
