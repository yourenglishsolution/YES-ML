<?php 
$QuizzTitle = "Common verbs";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "7E7CI",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "DK5GF",
			"QuestionTitle" => "Vocabulary",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "4IHWS",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the pictures with the words.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "to hit", 'right' => "", 'distractor' => false), array('left' => "to catch", 'right' => "A1_U3_tocatch.jpg", 'distractor' => false), array('left' => "to score", 'right' => "A1_U3_to_score_B.jpg", 'distractor' => false)),
			"Lefts" => array("to hit", "to catch", "to score"),
			"Rights" => array("", "A1_U3_tocatch.jpg", "A1_U3_to_score_B.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "BCYAK",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Select whether you 'watch' or 'see' the nouns.</i>",

			"Type" => "TABQCU",

			"Answers" => array("A1_U1_sun.jpg", "A1P_U6_cinema.jpg", "A1P_U6_envelope.jpg", "A1P_U5_presentation.jpg"),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>WATCH<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>SEE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("false", "true"),
								array("true", "false"),
								array("false", "true"),
								array("true", "false")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JZK0R",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the pictures to the words.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "to kick", 'right' => "A1_U3_to_kick.jpg", 'distractor' => false), array('left' => "to play", 'right' => "A1_U3_play.jpg", 'distractor' => false), array('left' => "to throw", 'right' => "A1_U3_throw.jpg", 'distractor' => false)),
			"Lefts" => array("to kick", "to play", "to throw"),
			"Rights" => array("A1_U3_to_kick.jpg", "A1_U3_play.jpg", "A1_U3_throw.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "KCODU",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the pictures to the words.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "to eat", 'right' => "A1_U3_eat.jpg", 'distractor' => false), array('left' => "to drink", 'right' => "A1_U3_drink.jpg", 'distractor' => false), array('left' => "to go", 'right' => "A1_U3_go.jpg", 'distractor' => false)),
			"Lefts" => array("to eat", "to drink", "to go"),
			"Rights" => array("A1_U3_eat.jpg", "A1_U3_drink.jpg", "A1_U3_go.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JS1SM",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>