<?php 

$Type = "Quizz";
$Title = "The weather";
$Author = "WR: DC CY. PR:LF.";
$Description = "It's nice to see you again. Let's begin!";
$Version = "2.7.2.0";
$Locale = "en.js";

?>