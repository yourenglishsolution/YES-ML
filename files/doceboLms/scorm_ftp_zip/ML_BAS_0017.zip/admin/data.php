<?php 
$QuizzTitle = "The weather";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "S1OXM",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "P822W",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>What can you say about the weather?</i><br>For example: <i>windy and cold &#8594; \"Brr. I need my jacket.\"</i><br/>sunny and warm <b> &#8594;</b> [<span style=\"border-bottom: 1px black dashed\">\"Nice weather we're having, isn't it?\"</span>]<br><br>rainy <b> &#8594; </b>[<span style=\"border-bottom: 1px black dashed\">\"Don't forget your umbrella!\"</span>]<br><br>sunny and snowy <b> &#8594;</b> [<span style=\"border-bottom: 1px black dashed\">\"I'm going skiing today!\"</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "CDONA",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "[[snd:sound1.mp3]]<br><br><i>What is the weather like?</i>",

			"Type" => "QCU",

			"Answers" => array("It's rainy.", "It's cold.", "It's sunny.", "It's too hot."),
			"Correct_Answers" => array("false", "false", "true", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "G8KN0",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "[[snd:sound2.mp3]]<br><br><i>Describe the weather.</i>",

			"Type" => "QCU",

			"Answers" => array("&quot;It's a nice day today.&quot;", "&quot;The weather is awful today.&quot;", "&quot;The weather is okay.&quot;", "&quot;It's a good day to go outside.&quot;"),
			"Correct_Answers" => array("false", "true", "false", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "RH68C",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>