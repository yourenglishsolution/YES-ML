<?php 
$QuizzTitle = "Sentences";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "6ZYET",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "LIXB1",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Drag and drop your answers to match the pictures on the right with their descriptions on the left.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "a French man", 'right' => "", 'distractor' => false), array('left' => "a German woman", 'right' => "", 'distractor' => false), array('left' => "an Italian woman", 'right' => "", 'distractor' => false)),
			"Lefts" => array("a French man", "a German woman", "an Italian woman"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "SVWWZ",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Choose the missing word to fill in the gap.</i><br/>&quot;Where [<span style=\"border-bottom: 1px black dashed\">are</span>] you from?&quot;<br>&quot;Where [<span style=\"border-bottom: 1px black dashed\">do</span>] you live?&quot;<br>&quot;[<span style=\"border-bottom: 1px black dashed\">Do</span>] you live in the UK?&quot;<br>&quot;[<span style=\"border-bottom: 1px black dashed\">Are</span>] you from the US?&quot;",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "S7YXP",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Select whether these sentences are correct or incorrect. </i><br><i></i><br><i></i>For example: <i>Do you live France? &#8594; INCORRECT. </i>",

			"Type" => "TABQCU",

			"Answers" => array("\"What do you do?\"", "\"Where do you do?\"", "\"Where do you work?\"", "\"What do you work?\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>CORRECT<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>INCORRECT<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("true", "false"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "FYNZ4",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Fill in the gap with the correct word to complete the sentence.</i><br/>&quot;How old are you?&quot;<br>&quot;I [<span style=\"border-bottom: 1px black dashed\">am</span>] 45.&quot;<br><br>&quot;How old is he?&quot;<br>&quot;He [<span style=\"border-bottom: 1px black dashed\">is</span>] 17.&quot;<br><br>&quot;How old is she?&quot;<br>&quot;She [<span style=\"border-bottom: 1px black dashed\">is</span>] 22.&quot;",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "YVBYN",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>