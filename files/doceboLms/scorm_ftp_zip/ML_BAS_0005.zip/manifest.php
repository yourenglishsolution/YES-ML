<?php 

$Type = "Quizz";
$Title = "Sentences";
$Author = "WR: RB. PR: LF.";
$Description = "Hello again. Today, we're going to look at phrases, and sentences.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>