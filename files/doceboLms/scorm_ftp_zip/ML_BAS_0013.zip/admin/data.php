<?php 
$QuizzTitle = "Review";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "2L4H3",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "NG5CV",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Write the correct adjective next to the picture.</i><br/>A1_U2_dry.jpg &#8594; <b>d</b>[<span style=\"border-bottom: 1px black dashed\">dry</span>, <span style=\"border-bottom: 1px black dashed\">dry.</span>, <span style=\"border-bottom: 1px black dashed\">ry</span>, <span style=\"border-bottom: 1px black dashed\">ry.</span>]<br><br>A1_U2_empty.jpg &#8594; <b>e</b>[<span style=\"border-bottom: 1px black dashed\">empty</span>, <span style=\"border-bottom: 1px black dashed\">empty.</span>, <span style=\"border-bottom: 1px black dashed\">mpty</span>, <span style=\"border-bottom: 1px black dashed\">mpty.</span>]<br><br>A1_U2_fast.jpg &#8594; <b>f</b>[<span style=\"border-bottom: 1px black dashed\">ast</span>, <span style=\"border-bottom: 1px black dashed\">ast.</span>, <span style=\"border-bottom: 1px black dashed\">fast</span>, <span style=\"border-bottom: 1px black dashed\">fast.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "48AWV",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "5",
	
			"Question" => "<i>Type the number is words beside its figure. </i><br><i></i>For example: <i>5 &#8594; five</i><br/>11 &#8594; [<span style=\"border-bottom: 1px black dashed\">eleven</span>, <span style=\"border-bottom: 1px black dashed\">eleven.</span>]<br><br>13 &#8594; [<span style=\"border-bottom: 1px black dashed\">thirteen</span>, <span style=\"border-bottom: 1px black dashed\">thirteen.</span>]<br><br>15 &#8594; [<span style=\"border-bottom: 1px black dashed\">fifteen</span>, <span style=\"border-bottom: 1px black dashed\">fifteen.</span>]<br><br>22 &#8594; [<span style=\"border-bottom: 1px black dashed\">twenty-two</span>, <span style=\"border-bottom: 1px black dashed\">twenty-two.</span>]<br><br>47 &#8594; [<span style=\"border-bottom: 1px black dashed\">forty-seven</span>, <span style=\"border-bottom: 1px black dashed\">forty-seven.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "S76K1",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "5",
	
			"Question" => "<i>Look at the family tree, and use the information to decide whether the statements are 'true' or 'false'.</i><br><br>family_B.jpg",

			"Type" => "TABQCU",

			"Answers" => array("A and B are parents.", "A is D's grandfather.", "D and C are brother and sister.", "B is A's wife.", "D is an only child."),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>TRUE<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>FALSE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("true", "false"),
								array("true", "false"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>