<?php 
$QuizzTitle = "Writing Numbers";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "4FBPB",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "CU2S5",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Write the correct number in each blank to complete the pattern. </i><br><br>For example: <i>one, two, ____, four &#8594; three.</i><br/>ten, [<span style=\"border-bottom: 1px black dashed\">eleven</span>], twelve, thirteen<br><br>[<span style=\"border-bottom: 1px black dashed\">fifteen</span>], sixteen, seventeen<br><br>twenty, twenty-one, [<span style=\"border-bottom: 1px black dashed\">twenty-two</span>], twenty-three<br><br>first, second, [<span style=\"border-bottom: 1px black dashed\">third</span>], fourth",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "ESPAB",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the recording. Two of the numbers below are spoken during the recording. Select the two correct numbers.</i><br><br>[[snd:A1_U1_M2_006b.mp3]]",

			"Type" => "QCM",

			"Answers" => array("16", "70", "18", "90"),
			"Correct_Answers" => array("false", "true", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "TK3FH",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the recording, and type in the two numbers you hear to fill in the gaps.</i><br><br>[[snd:A1_U1_M2_007b.mp3]]<br/>She said, &quot;[<span style=\"border-bottom: 1px black dashed\">Forty</span>]-four, [<span style=\"border-bottom: 1px black dashed\">fifty</span>]-five.&quot;",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "TP06H",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Listen to the sound recording  to answer the question.</i><br><br>[[snd:A1_U1_M2_0017d.mp3]]<br><br>Where is his office?",

			"Type" => "QCU",

			"Answers" => array("on the six floor", "on the fifth floor", "in the sixth floor", "on the sixth floor"),
			"Correct_Answers" => array("false", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "0QOM1",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording, and fill in the gaps that are missing.</i><br><br>[[snd:A1_U1_M2_0017c.mp3]]<br><br>What did she say?<br/>The [<span style=\"border-bottom: 1px black dashed\">3</span>, <span style=\"border-bottom: 1px black dashed\">three</span>] girls [<span style=\"border-bottom: 1px black dashed\">ate pizza</span>]<b>.</b>",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "UBONF",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>