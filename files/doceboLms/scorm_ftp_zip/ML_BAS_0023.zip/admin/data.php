<?php 
$QuizzTitle = "Review";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "7ECTR",
			"QuestionTitle" => "Word of the Day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "CTMQC",
			"QuestionTitle" => "Review",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "P0DHX",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Fill in the blanks with 'like' or 'don't like'.</i><br>For example:<br><i>- I don't like driving.</i><br><i>- Me neither.</i><br/>- I [<span style=\"border-bottom: 1px black dashed\">like</span>] sports a lot.<br>- Me too!<br><br>- I [<span style=\"border-bottom: 1px black dashed\">like</span>] dogs. I have three.<br>- Me too!<br><br>- Baseball is boring. I [<span style=\"border-bottom: 1px black dashed\">don't like</span>] it.<br>- Me neither.",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "4IHWS",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",

			"Question" => "<i>Match the sentences together.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "[[snd:A1_U2_M3_Q008c.mp3]]", 'right' => "[[snd:A1_U2_M3_Q008d.mp3]]", 'distractor' => false), array('left' => "[[snd:A1_U2_M3_Q008a.mp3]]", 'right' => "[[snd:A1_U2_M3_Q008b.mp3]]", 'distractor' => false)),
			"Lefts" => array("[[snd:A1_U2_M3_Q008c.mp3]]", "[[snd:A1_U2_M3_Q008a.mp3]]"),
			"Rights" => array("[[snd:A1_U2_M3_Q008d.mp3]]", "[[snd:A1_U2_M3_Q008b.mp3]]"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EM645",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>'Is' or 'are'?</i><br><br><b>EXAMPLE:</b><br><br><b>Why ____ he so late? &#8594; Why<font color=\"#FF0000\"> </b></font>is <b>he so late?</b>",

			"Type" => "TABQCU",

			"Answers" => array("<br>____ he here?", "<br>Where ____ they from?", "<br>What ____ we going to do?", "<br>What ____ your name?"),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>IS<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>ARE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("true", "false"),
								array("false", "true"),
								array("false", "true"),
								array("true", "false")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "6IWRE",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>'Do' or 'does'?</i><br><br><b>EXAMPLE:</b><br><br><b>____ Nicholas work all day? &#8594; </b>Does <b>Nicholas work all day?</b><br/><b>1.</b><br>[<span style=\"border-bottom: 1px black dashed\">Do</span>] you like chicken?<br><br><b>2.</b><br>[<span style=\"border-bottom: 1px black dashed\">Does</span>] Peter have glasses?<br><br><b>3.</b><br>[<span style=\"border-bottom: 1px black dashed\">Do</span>] Helen and Justin work on Mondays?",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "DJO6V",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "[[snd:A1_U3_M1_Q073b.mp3]]<br><br><i>What does she have?</i>",

			"Type" => "QCM",

			"Answers" => array("A1_U3_runny_nose.jpg", "A1_U3_fever.jpg", "A1_U3_headache.jpg", "A1_U3_sore_throat.jpg"),
			"Correct_Answers" => array("true", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "YRT0S",
			"QuestionTitle" => "Q6",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match the text to the pictures.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "a cramp", 'right' => "A1_U3_cramp.jpg", 'distractor' => false), array('left' => "a cut", 'right' => "A1_U3_cut.jpg", 'distractor' => false), array('left' => "a headache", 'right' => "A1_U3_headache.jpg", 'distractor' => false)),
			"Lefts" => array("a cramp", "a cut", "a headache"),
			"Rights" => array("A1_U3_cramp.jpg", "A1_U3_cut.jpg", "A1_U3_headache.jpg"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "PJ2OY",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>