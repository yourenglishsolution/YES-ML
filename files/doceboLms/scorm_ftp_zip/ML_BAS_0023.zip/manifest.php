<?php 

$Type = "Quizz";
$Title = "Review";
$Author = "WR: PR: LF";
$Description = "Hello there. Let's go.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>