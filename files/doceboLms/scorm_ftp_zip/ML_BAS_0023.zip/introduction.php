<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><?php 	
	class QuestionDisplayer extends QuestionDisplayerBase
	{
		function QuestionDisplayer()
		{
			$this->QuestionDisplayerBase();
			$this->QuestionType = 'introduction';
		}

		function DisplayPage()
		{
?><html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Review</title>
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans|Droid+Serif|Droid+Sans+Mono">
<link rel="stylesheet" type="text/css" href="_ressources/style.css" media="all"><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script><script src="_ressources/javascripts/jquery.formalize.js"></script><link rel="stylesheet" href="_images/default_css.css" type="text/css"><script type="text/javascript" language="JavaScript" src="_scripts/prototype.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/language.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_default_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_lang/en.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/OpenPopupImage.js"></script><script type="text/javascript" language="JavaScript" src="_scripts/InlineMedia.js"></script><script type="text/javascript" language="JavaScript">
		
		var AvailableMedia = new Array();
		
		AvailableMedia[0] = "A1P_U4_bdp_hand.jpg";
		
		AvailableMedia[1] = "A1P_U4_bdp_head.jpg";
		
		AvailableMedia[2] = "A1P_U4_bdp_knee.jpg";
		
		AvailableMedia[3] = "A1P_U4_bdp_legs.jpg";
		
		AvailableMedia[4] = "A1P_U4_bdp_neck.jpg";
		
		AvailableMedia[5] = "A1P_U4_bdp_shoulder.jpg";
		
		AvailableMedia[6] = "A1_U1_sunny.jpg";
		
		AvailableMedia[7] = "A1_U2_M3_Q008a.mp3";
		
		AvailableMedia[8] = "A1_U2_M3_Q008b.mp3";
		
		AvailableMedia[9] = "A1_U2_M3_Q008c.mp3";
		
		AvailableMedia[10] = "A1_U2_M3_Q008d.mp3";
		
		AvailableMedia[11] = "A1_U2_window.jpg";
		
		AvailableMedia[12] = "A1_U3_acold.jpg";
		
		AvailableMedia[13] = "A1_U3_broken_leg.jpg";
		
		AvailableMedia[14] = "A1_U3_cough.jpg";
		
		AvailableMedia[15] = "A1_U3_cramp.jpg";
		
		AvailableMedia[16] = "A1_U3_cut.jpg";
		
		AvailableMedia[17] = "A1_U3_cycling.jpg";
		
		AvailableMedia[18] = "A1_U3_dizzy.jpg";
		
		AvailableMedia[19] = "A1_U3_earache.jpg";
		
		AvailableMedia[20] = "A1_U3_fever.jpg";
		
		AvailableMedia[21] = "A1_U3_headache.jpg";
		
		AvailableMedia[22] = "A1_U3_M1_Q009a.mp3";
		
		AvailableMedia[23] = "A1_U3_M1_Q073b.mp3";
		
		AvailableMedia[24] = "A1_U3_nauseous.jpg";
		
		AvailableMedia[25] = "A1_U3_runny_nose.jpg";
		
		AvailableMedia[26] = "A1_U3_sore_throat.jpg";
		
		AvailableMedia[27] = "A1_U3_stomachache.jpg";
		
		AvailableMedia[28] = "A1_U6_door.jpg";
		
		AvailableMedia[29] = "A1_W4_D3_window.mp3";
		
		AvailableMedia[30] = "A1_W4_D4_door.mp3";
		
		AvailableMedia[31] = "A1_W5_D1_sick.mp3";
		
		AvailableMedia[32] = "A1_W5_D2_cough.mp3";
		
		AvailableMedia[33] = "A1_W5_D4_sorethroat.mp3";
		
		AvailableMedia[34] = "bike.jpg";
		
		AvailableMedia[35] = "screenshot_01.jpg";
		
		AvailableMedia[36] = "screenshot_02.jpg";
		
		AvailableMedia[37] = "screenshot_03.jpg";
		
		AvailableMedia[38] = "screenshot_04.jpg";
		
		AvailableMedia[39] = "sound1.mp3";
		
		AvailableMedia[40] = "sound2.mp3";
		
		AvailableMedia[41] = "Thumbs.db";
		

		var AvailableReducedImages = new Array();
		</script><meta http-equiv="imagetoolbar" content="no">
</head>
<body dir="ltr">
<form name="MyQuizzForm" action="_ManagerFrame.php" method="get"><input type="hidden" name="PageNumber" value="-1"><input type="hidden" name="Direction" value="1"><div id="core">
</div>
<div id="cntrls">
<div id="cntrls_c">
<div id="cntrls_dcrs"></div>
<div id="cntrls_btns">
<div id="btn_start"><a class="Start" id="Start" href="javascript:document.forms[0].submit();"><img src="_images/img_start.png" align="middle" border="0"></a></div>
</div>
</div>
</div>
<div id="intro">
<div class="intro_title">Review</div>
<p class="txt"><span class="description ProcessInlineImages" id="description">Hello there. Let's go.</span></p>
</div><script type="text/javascript" language="JavaScript">
bDontScrollDraggables = true;
</script></form><script type="text/javascript" language="JavaScript">
	EpiLangManager.TranslatePage(document) ;
</script></body>
</html><?php 
		} // DisplayPage
	}; // class
	
	$PageDisplay = new QuestionDisplayer();
	
?>
