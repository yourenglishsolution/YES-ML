<?php 

$Type = "Quizz";
$Title = "Likes & Dislikes";
$Author = "WR: DC CY. PR:LF";
$Description = "Hello, let's begin your lesson.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>