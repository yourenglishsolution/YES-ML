<?php 
$QuizzTitle = "Likes & Dislikes";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "8FA2X",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "P0DHX",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Fill in the blanks with 'like' or 'don't like'.</i><br>For example:<br><i>- I don't like driving.</i><br><i>- Neither do I.</i><br/>- I [<span style=\"border-bottom: 1px black dashed\">like</span>] sports a lot.<br>- Me too!<br><br>- I [<span style=\"border-bottom: 1px black dashed\">like</span>] dogs.<br>- Me too!<br><br>- Baseball is boring. I [<span style=\"border-bottom: 1px black dashed\">don't like</span>] it.<br>- Me neither.",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "4IHWS",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",

			"Question" => "<i>Match the sentences together. Drag and drop the sound recording.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "[[snd:A1_U2_M3_Q008c.mp3]]", 'right' => "[[snd:A1_U2_M3_Q008d.mp3]]", 'distractor' => false), array('left' => "[[snd:A1_U2_M3_Q008a.mp3]]", 'right' => "[[snd:A1_U2_M3_Q008b.mp3]]", 'distractor' => false)),
			"Lefts" => array("[[snd:A1_U2_M3_Q008c.mp3]]", "[[snd:A1_U2_M3_Q008a.mp3]]"),
			"Rights" => array("[[snd:A1_U2_M3_Q008d.mp3]]", "[[snd:A1_U2_M3_Q008b.mp3]]"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "BCYAK",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Choose 'me too' or 'me neither' to finish the sentence.</i><br>For example: <i>I love croissants. &#8594; Me too!</i>",

			"Type" => "TABQCU",

			"Answers" => array("<br>I don't really like beer.", "<br>I love wine!", "<br>I thought the movie was great!", "<br>I don't think Robbie is very nice."),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>ME TOO<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>ME NEITHER<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("false", "true"),
								array("true", "false"),
								array("true", "false"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "LW27E",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Choose the correct verb for each sentence.</i><br>For example: <i>Anchovies are too salty. I <u>do not like </u>them at all. </i><br/>She [<span style=\"border-bottom: 1px black dashed\">hates</span>] going to the dentist! She thinks it's horrible.<br><br>I [<span style=\"border-bottom: 1px black dashed\">love</span>] fish. It tastes delicious!<br><br>He [<span style=\"border-bottom: 1px black dashed\">doesn't like</span>] the rain, but he tolerates it.",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "JS1SM",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>