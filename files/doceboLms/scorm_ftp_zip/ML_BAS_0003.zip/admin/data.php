<?php 
$QuizzTitle = "Pronouns";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "MEA56",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "3L2LV",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Drag and drop your answers to match the the pronoun on the left with its picture on the right.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "I", 'right' => "", 'distractor' => false), array('left' => "we", 'right' => "", 'distractor' => false), array('left' => "they", 'right' => "", 'distractor' => false)),
			"Lefts" => array("I", "we", "they"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "MTM4T",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Use the drop-down menu to match the pronoun with the correct image.</i>",
			"Type" => "MATCH",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "V3X7N",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Complete the sentences by choosing the correct word from the drop-down menu.</i>",
			"Type" => "MATCH",
			"Answers" => array("We", "He", "I"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "7Z74T",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Fill in the gap by writing the correct pronoun (</i><b>I, we, he, she, it, they, or you)</b><i>  in the space.</i><br/>John<b> </b>is sleeping. [<span style=\"border-bottom: 1px black dashed\">He</span>] is in bed.<br><br>Emilie and I are listening to music. [<span style=\"border-bottom: 1px black dashed\">We</span>] are listening to the radio.<br><br>This computer<b> </b>is old! [<span style=\"border-bottom: 1px black dashed\">It</span>] doesn't work.<br><br>I have two pens. [<span style=\"border-bottom: 1px black dashed\">They</span>] are in my bag.",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "BGOXC",
			"QuestionTitle" => "Q5",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Select the correct words to complete the sentences.</i><br><i></i><br>For example: <i>Do you ____ in France? &#8594; LIVE</i>",

			"Type" => "TABQCU",

			"Answers" => array("\"Do you ____ in France?\"", "\"Where are you ____?\"", "\"Are you ____ London?\"", "\"Where do you ____?\""),
			"Columns" => array("<font color=\"#FFFFFF\"><b>--</font>FROM<font color=\"#FFFFFF\">--</b></font>", "<font color=\"#FFFFFF\"><b>--</font>LIVE<font color=\"#FFFFFF\">--</b></font>"),
			"Correct_Answers" => array(array("false", "true"),
								array("true", "false"),
								array("true", "false"),
								array("false", "true")),			

			"HasComments" => false,

			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "70OX8",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>