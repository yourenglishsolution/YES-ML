<?php 

$Type = "Quizz";
$Title = "Pronouns";
$Author = "WR: RB. PR: LF.";
$Description = "Welcome to your microlearning! Today, we will work on pronouns.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>