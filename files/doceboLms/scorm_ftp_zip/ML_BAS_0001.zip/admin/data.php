<?php 
$QuizzTitle = "Letters";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "OLB16",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "PN3UQ",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>Match each colour on the left with its name on the right.</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "blue", 'right' => "", 'distractor' => false), array('left' => "yellow", 'right' => "", 'distractor' => false), array('left' => "red", 'right' => "", 'distractor' => false)),
			"Lefts" => array("blue", "yellow", "red"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "7GEDS",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Listen to the sound recording, and write down the letters you hear. Write one letter per space.</i><br><br>[[snd:A1_U1_M1_VP5.mp3]]<br/>[<span style=\"border-bottom: 1px black dashed\">G</span>, <span style=\"border-bottom: 1px black dashed\">G,</span>, <span style=\"border-bottom: 1px black dashed\">G.</span>], [<span style=\"border-bottom: 1px black dashed\">P</span>, <span style=\"border-bottom: 1px black dashed\">P,</span>, <span style=\"border-bottom: 1px black dashed\">P.</span>], [<span style=\"border-bottom: 1px black dashed\">T</span>, <span style=\"border-bottom: 1px black dashed\">T,</span>, <span style=\"border-bottom: 1px black dashed\">T.</span>], [<span style=\"border-bottom: 1px black dashed\">V</span>, <span style=\"border-bottom: 1px black dashed\">V,</span>, <span style=\"border-bottom: 1px black dashed\">V.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "NUKYF",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Listen to the sound recording, and write down the letters you hear. Write one letter per space.</i><br><br>[[snd:A1_U1_M1_VP2.mp3]]<br/>[<span style=\"border-bottom: 1px black dashed\">J</span>, <span style=\"border-bottom: 1px black dashed\">J,</span>, <span style=\"border-bottom: 1px black dashed\">J.</span>], [<span style=\"border-bottom: 1px black dashed\">G</span>, <span style=\"border-bottom: 1px black dashed\">G,</span>, <span style=\"border-bottom: 1px black dashed\">G.</span>], [<span style=\"border-bottom: 1px black dashed\">K</span>, <span style=\"border-bottom: 1px black dashed\">K,</span>, <span style=\"border-bottom: 1px black dashed\">K.</span>], [<span style=\"border-bottom: 1px black dashed\">I</span>, <span style=\"border-bottom: 1px black dashed\">I,</span>, <span style=\"border-bottom: 1px black dashed\">I.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "XEQVZ",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "<i>Listen to the sound recording, and write down the letters you hear. There are four letters to write down.</i><br><br>[[snd:A1_U1_M1_VP4.mp3]]<br/>[<span style=\"border-bottom: 1px black dashed\">B, C, D, E</span>]",
			"Type" => "TAT",
			"Answers" => array(""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "Q05SZ",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>