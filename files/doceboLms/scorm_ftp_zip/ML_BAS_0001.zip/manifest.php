<?php 

$Type = "Quizz";
$Title = "Letters";
$Author = "WR: RB. PR: LF.";
$Description = "Hello and welcome to your microlearning. Today, we will learn about colours, and letters.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>