<?php 
$QuizzTitle = "Review";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "K4YWP",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "3KORW",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "<i>What does the picture show?</i><br>For example:<i> sunny &#8594; A1_U1_sunny.jpg</i>",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "cloudy", 'right' => "", 'distractor' => false), array('left' => "freezing", 'right' => "", 'distractor' => false), array('left' => "windy", 'right' => "", 'distractor' => false)),
			"Lefts" => array("cloudy", "freezing", "windy"),
			"Rights" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "ZZ42I",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Answer the questions.</i><br>For example:<b> </b><i>When do you wear skis? &#8594; When it's snowy.</i><br/>When do you use an umbrella? &#8594; When it's [<span style=\"border-bottom: 1px black dashed\">rainy</span>].<br><br>When do you wear a winter coat? &#8594; When it's [<span style=\"border-bottom: 1px black dashed\">cold</span>].<br><br>When do you wear a t-shirt and shorts? &#8594; When it's [<span style=\"border-bottom: 1px black dashed\">hot</span>].",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "2WPYW",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Make this sentence negative (-):</i><br>For example: <i>I eat croissants &#8594; I don't eat croissants.</i><br/>I like Jim. He's a good man.<br><b>&#8594; </b>I [<span style=\"border-bottom: 1px black dashed\">do not</span>, <span style=\"border-bottom: 1px black dashed\">don't</span>] like Jim. He's [<span style=\"border-bottom: 1px black dashed\">not</span>] a good man.",
			"Type" => "TAT",
			"Answers" => array("", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "ZO5TR",
			"QuestionTitle" => "Q4",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "4",
	
			"Question" => "<i>Put the conversation in order from 1 to 4.</i>",
			"Type" => "SORT",
			"Answers" => array("&quot;Here you are.&quot;", "&quot;No problem.&quot;", "&quot;Pass the salt, please.&quot;", "&quot;Thanks!&quot;"),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "B8YTE",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>