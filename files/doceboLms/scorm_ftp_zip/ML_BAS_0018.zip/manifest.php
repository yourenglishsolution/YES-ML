<?php 

$Type = "Quizz";
$Title = "Review";
$Author = "WR: DC. PR:LF.";
$Description = "Welcome back. Are you ready? Let's go!";
$Version = "2.7.2.0";
$Locale = "en.js";

?>