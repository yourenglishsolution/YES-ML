<?php 
$QuizzTitle = "Asking for things";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "Epistema LMS";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "T81FK",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "0DAZB",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the sound recording, and select the two responses you could use.</i><br><br>[[snd:A1_U2_M1_Q004a.mp3]]",

			"Type" => "QCM",

			"Answers" => array("&quot;Is a red one okay?&quot;", "&quot;Yes, they are here.&quot;", "&quot;I'm sorry. I don't.&quot;", "&quot;Yes. It's three-fifteen.&quot;"),
			"Correct_Answers" => array("true", "false", "true", "false"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "AILRH",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>The sentences below are not in the correct order. Organise the sentences so that they are correct. </i><br><br>For example: <i>have do you time the ? &#8594; Do you have the time?</i><br/><b>you have pen a black do? </b><br><b>&#8594; </b>[<span style=\"border-bottom: 1px black dashed\">Do you have a black pen</span>, <span style=\"border-bottom: 1px black dashed\">Do you have a black pen ?</span>, <span style=\"border-bottom: 1px black dashed\">Do you have a black pen?</span>]<br><br><b>do I yes</b><br><b>&#8594; </b>[<span style=\"border-bottom: 1px black dashed\">Yes I do</span>, <span style=\"border-bottom: 1px black dashed\">Yes I do.</span>, <span style=\"border-bottom: 1px black dashed\">Yes, I do</span>, <span style=\"border-bottom: 1px black dashed\">Yes, I do.</span>]<br><br><b>don't no I</b><br><b>&#8594; </b>[<span style=\"border-bottom: 1px black dashed\">No I don't</span>, <span style=\"border-bottom: 1px black dashed\">No I don't.</span>, <span style=\"border-bottom: 1px black dashed\">No, I don't</span>, <span style=\"border-bottom: 1px black dashed\">No, I don't.</span>]",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "4GXVH",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "2",
	
			"Question" => "<i>Listen to the four sound recordings, and select the two that are correct answers to the question 'Do you have the time?'</i>",

			"Type" => "QCM",

			"Answers" => array("[[snd:A1_U2_M1_Q004b.mp3]]", "[[snd:A1_U2_M1_Q007b.mp3]]", "[[snd:A1_U2_M1_Q007a.mp3]]", "[[snd:A1_U2_M1_Q004c.mp3]]"),
			"Correct_Answers" => array("true", "false", "false", "true"),
			"Comments" => array("", "", "", ""),
			"Profiles" => array("", "", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>