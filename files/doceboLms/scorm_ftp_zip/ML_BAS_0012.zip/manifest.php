<?php 

$Type = "Quizz";
$Title = "Asking for things";
$Author = "PR: CY. PR: LF";
$Description = "Today, we're going to practice asking for things. But, let's see the Word of the Day first.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>