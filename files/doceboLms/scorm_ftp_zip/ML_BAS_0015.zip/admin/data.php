<?php 
$QuizzTitle = "Negative sentences";
$Passwd = "";

$LangFile = "en.js";
$Encoding = "UTF-8";


$LogoImage = "";


$CopyrightText = "YES-Your English Solution";
$CopyrightURL = "";

$IsAdaptivePath = false;				

$ScoreComments = array();


$Themes = array();



$Profiles = array();



$QuestionDefinition[] = array(
			"UID" => "3AW4O",
			"QuestionTitle" => "Word of the day",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);


$QuestionDefinition[] = array(
			"UID" => "FUXWC",
			"QuestionTitle" => "Q1",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "1",
	
			"Question" => "[[snd:A1_U2_M1_Q025a.mp3]]<br><br><i>Select the sentence that has the opposite meaning to the sound recording.</i>",

			"Type" => "QCU",

			"Answers" => array("He hasn't happy.", "He is happy not.", "He isn't happy."),
			"Correct_Answers" => array("false", "false", "true"),
			"Comments" => array("", "", ""),
			"Profiles" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "FZAIM",
			"QuestionTitle" => "Q2",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",

			"Question" => "Select the sentence that has the opposite meaning to the sound recording.",
			"Type" => "DRAGDROP",
			"Version" => "2",
			"Rows" => array(array('left' => "[[snd:A1_U2_M1_Q025c.mp3]]", 'right' => "He isn't tired.", 'distractor' => false), array('left' => "[[snd:A1_U2_M1_Q025b.mp3]]", 'right' => "He isn't sad.", 'distractor' => false), array('left' => "[[snd:A1_W3_D5_a.mp3]]", 'right' => "This isn't a bird.", 'distractor' => false)),
			"Lefts" => array("[[snd:A1_U2_M1_Q025c.mp3]]", "[[snd:A1_U2_M1_Q025b.mp3]]", "[[snd:A1_W3_D5_a.mp3]]"),
			"Rights" => array("He isn't tired.", "He isn't sad.", "This isn't a bird."),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "7BTVL",
			"QuestionTitle" => "Q3",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "false",
			"MaxScore" => "3",
	
			"Question" => "<i>Fill in the gap to make negative sentences. </i><br>For example: <i>she is hot</i>  &#8594<i> she isn't hot/ or she is not hot.</i><br/>He is happy. &#8594; <sub> </sub>He [<span style=\"border-bottom: 1px black dashed\">is not</span>, <span style=\"border-bottom: 1px black dashed\">isn't</span>, <span style=\"border-bottom: 1px black dashed\">'s not</span>] happy.<br><br>They are big. &#8594; They [<span style=\"border-bottom: 1px black dashed\">are not</span>, <span style=\"border-bottom: 1px black dashed\">aren't</span>, <span style=\"border-bottom: 1px black dashed\">'re not</span>] big.<br><br>I am hungry. &#8594; I [<span style=\"border-bottom: 1px black dashed\">am not</span>, <span style=\"border-bottom: 1px black dashed\">'m not</span>] hungry.",
			"Type" => "TAT",
			"Answers" => array("", "", ""),
			"Notions" => array()

);


$QuestionDefinition[] = array(
			"UID" => "EE8WD",
			"QuestionTitle" => "The end",
			"Theme" => "",
			"ThemeGUID" => "",
			"IsLastQuestionOfTheme" => "true",
			"MaxScore" => "0",
	
			"Type" => "EXPLANATION"

);



?>