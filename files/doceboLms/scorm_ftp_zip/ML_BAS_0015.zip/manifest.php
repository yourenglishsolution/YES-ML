<?php 

$Type = "Quizz";
$Title = "Negative sentences";
$Author = "WR: CY. PR: LF";
$Description = "Today, we're going to practice making negative sentences. But first, here's your Word of the Day.";
$Version = "2.7.2.0";
$Locale = "en.js";

?>